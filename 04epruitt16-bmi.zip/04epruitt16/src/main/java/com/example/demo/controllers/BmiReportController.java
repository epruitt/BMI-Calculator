package com.example.demo.controllers;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

public class BmiReportController {


	@GetMapping("/bmiresult")
	public ModelAndView report(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mav = new ModelAndView("pages/bmiReport");

		// variables for height in feet (the feet part), height in inches (the inches part), and weight (in pounds)
				String heightInFeetStr=request.getParameter("feet");
				System.err.println("H"+heightInFeetStr);
				String heightInInchesStr=request.getParameter("inches");
				String weightStr= request.getParameter("weight");
				String userStr= request.getParameter("user");
				//turning the string variable into a double variable
				double heightInFeet= Double.parseDouble(heightInFeetStr);
				double heightInInches= Double.parseDouble(heightInInchesStr);
				double weight= Double.parseDouble(weightStr);
				double tW= weight * 703; //total weight = converts client weight so it work with the formula 
				double tH= (heightInFeet*12)+heightInInches; // total height= client height in inches
				double bmi= tW/(tH*tH); // bmi = total weight  / (total height^2)


		mav.addObject("feet", heightInFeet);
		mav.addObject("inches", heightInInches);
		mav.addObject("weight", weight);
		mav.addObject("user", userStr);
		
		String str ="tba";
		if(bmi < 18.5 ) {
			str= "Your BMI is Underweight";
		}
		if((bmi == 18.5)||(bmi < 18.5 && bmi< 24.99) ) {
			str= "Your BMI is Normal weight";
		} 
		if((bmi == 25)||(bmi > 25 && bmi<29.99) ) {
			str="Your BMI is Overweight";
		}
		 if((bmi==30)||(bmi >30 && bmi< 34.99) ) {
			str="Your BMI is Obesity (class 1)";
		}
		 if((bmi==35)||(bmi > 35 && bmi< 39.99) ) {
			str="Your BMI is Obesity (class 2)";
		}
		 if (bmi >= 40 ) {
			str="Your BMI is Morbid Obesity ";
		}
		
		mav.addObject("result",str);



		return mav;

	}

//	private void bmiConverter(HttpServletRequest request, PrintWriter out) {
//
//		// variables for height in feet (the feet part), height in inches (the inches part), and weight (in pounds)
//		String heightInFeetStr=request.getParameter("Feet");
//		System.err.println("H"+heightInFeetStr);
//		String heightInInchesStr=request.getParameter("Inches");
//		String weightStr= request.getParameter("weight");
//
//		//turning the string variable into a double variable
//		double heightInFeet= Double.parseDouble(heightInFeetStr);
//		double heightInInches= Double.parseDouble(heightInInchesStr);
//		double weight= Double.parseDouble(weightStr);
//		double tW= weight * 703; //total weight = converts client weight so it work with the formula 
//		double tH= (heightInFeet*12)+heightInInches; // total height= client height in inches
//
//
//		double bmi= tW/(tH*tH); // bmi = total weight  / (total height^2)
//
//		// Result from the BMI formula
//
//		if(bmi < 18.5 ) {
//			out.println("$<result>= <p>Your BMI is Underweight</p>");
//		}else if((bmi == 18.5)||(bmi < 18.5 && bmi< 24.99) ) {
//			out.println("$<result>= <p>Your BMI is Normal weight</p>");
//		}else if((bmi == 25)||(bmi > 25 && bmi<29.99) ) {
//			out.println("$<result>= <p>Your BMI is Overweight</p>");
//		}
//		else if((bmi==30)||(bmi >30 && bmi< 34.99) ) {
//			out.println("$<result>= <p>Your BMI is Obesity (class 1)</p>");
//		}
//		else if((bmi==35)||(bmi > 35 && bmi< 39.99) ) {
//			out.println("$<result>= <p>Your BMI is Obesity (class 2)</p>");
//		}else if (bmi >= 40 ) {
//			out.println("$<result>= <p>Your BMI is Morbid Obesity</p> ");
//		}
//	}

}
